# CodeHunter-X Android

هذا المشروع يحوّل نسخة Tkinter إلى تطبيق Android باستخدام Kivy.

## بناء APK

على Linux/WSL:
1. ثبّت Python وJava وBuildozer.
2. ادخل إلى مجلد المشروع.
3. نفّذ:
   buildozer android debug
4. ستجد ملف APK داخل مجلد `bin/`.

لنسخة قابلة للتثبيت على هاتفك، استخدم:
   buildozer android debug deploy run

ملاحظة: التطبيق محاكاة محلية فقط؛ الرمز السري يُولّد داخل التطبيق ولا يتصل بأي خدمة خارجية.
