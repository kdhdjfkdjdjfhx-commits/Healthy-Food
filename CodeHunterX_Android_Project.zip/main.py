from kivy.app import App
from kivy.clock import Clock
from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.progressbar import ProgressBar
from kivy.uix.button import Button
from kivy.core.window import Window
import random
import time

class CodeHunterX(BoxLayout):
    def __init__(self, **kwargs):
        super().__init__(orientation="vertical", padding=dp(20), spacing=dp(10), **kwargs)
        self.secret = self.generate_secret()
        self.running = False
        self.current = 0
        self.attempts = 0
        self.start_time = 0.0
        self.event = None

        self.add_widget(Label(text="CodeHunter-X", font_size=dp(30), bold=True,
                              size_hint_y=None, height=dp(60)))
        self.add_widget(Label(text="6-Digit Local Simulation", font_size=dp(16),
                              size_hint_y=None, height=dp(35)))

        self.status = Label(text="Secret code generated locally.", font_size=dp(16))
        self.add_widget(self.status)

        self.progress = ProgressBar(max=1000000, value=0, size_hint_y=None, height=dp(20))
        self.add_widget(self.progress)

        self.guess_label = Label(text="Guess: ------", font_size=dp(25), bold=True)
        self.add_widget(self.guess_label)

        self.attempt_label = Label(text="Attempts: 0", font_size=dp(17))
        self.add_widget(self.attempt_label)

        self.time_label = Label(text="Time: 0.00 seconds", font_size=dp(17))
        self.add_widget(self.time_label)

        self.start_button = Button(text="START HUNT", font_size=dp(20),
                                   size_hint_y=None, height=dp(60))
        self.start_button.bind(on_press=self.start_hunt)
        self.add_widget(self.start_button)

        self.new_button = Button(text="NEW SECRET", font_size=dp(18),
                                 size_hint_y=None, height=dp(55))
        self.new_button.bind(on_press=self.new_secret)
        self.add_widget(self.new_button)

    def generate_secret(self):
        return f"{random.randint(0, 999999):06d}"

    def start_hunt(self, *_):
        if self.running:
            return
        self.running = True
        self.current = 0
        self.attempts = 0
        self.start_time = time.perf_counter()
        self.start_button.disabled = True
        self.status.text = "Searching..."
        self.hunt_step(0)

    def hunt_step(self, _dt):
        if not self.running:
            return

        batch_size = 5000
        end = min(self.current + batch_size, 1000000)

        for number in range(self.current, end):
            self.attempts += 1
            guess = f"{number:06d}"

            if guess == self.secret:
                self.current = number + 1
                self.running = False
                self.guess_label.text = f"Guess: {guess}"
                self.status.text = "CODE FOUND!"
                self.start_button.disabled = False
                self.update_display()
                return

        self.current = end
        self.update_display()

        # Let Android refresh the UI between batches.
        self.event = Clock.schedule_once(self.hunt_step, 0.01)

    def update_display(self):
        self.progress.value = self.current
        if self.current > 0:
            self.guess_label.text = f"Guess: {self.current - 1:06d}"
        self.attempt_label.text = f"Attempts: {self.attempts:,}"
        elapsed = time.perf_counter() - self.start_time
        self.time_label.text = f"Time: {elapsed:.2f} seconds"

    def new_secret(self, *_):
        self.running = False
        if self.event:
            self.event.cancel()
            self.event = None
        self.secret = self.generate_secret()
        self.current = 0
        self.attempts = 0
        self.progress.value = 0
        self.guess_label.text = "Guess: ------"
        self.attempt_label.text = "Attempts: 0"
        self.time_label.text = "Time: 0.00 seconds"
        self.status.text = "New secret generated locally."
        self.start_button.disabled = False


class CodeHunterXApp(App):
    title = "CodeHunter-X"

    def build(self):
        return CodeHunterX()

if __name__ == "__main__":
    CodeHunterXApp().run()
